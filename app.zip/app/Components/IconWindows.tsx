// "use client";
// import React, { useState } from "react";
// import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
// import { faClose } from "@fortawesome/free-solid-svg-icons";
// import { iconsData } from "@/iconsData";
// import { useGlobalContextProvider } from "../contextAPI";

// function IconsWindow() {
//     const [allIcons, setAllIcons] useState(iconsData); const iconBox, isDark
// } = useGlobalContextProvider(); const { openIconBox, setOpenIconBox } iconBox;
// return (<div
//     className={w - full
// left-0 flex absolute justify-center items-center top-50
//     openIconBox ? "flex" : "hidden"
// I
// `}
// <div
// className={relative z-50 w-[400px] p-4 rounded-md
// border flex flex-col gap-6 shadow-md ${
// isDark? "Obg-blackColorDark text-white": " bg-white text-black"
// }}
// >
// <FontAwesomeIcon
// />
// height={20}
// width={20}
// className={ ${
// isDark? "Obg-blackColorDark" : bg-white"
// } absolute top - 8 right - 4
// icon - { faClose }
// Itext - gray - 300 cursor - pointer`}
// onClick={() => setOpenIconBox (false)}
// <span className="font-bold text-lg
// Choose Your Icon
// </span>
// bg-transparent mt-3 ">

// 2:10:23
